//+------------------------------------------------------------------+
//|                                              STRATUM_Desk.mq4    |
//|  Мультивалютный эксперт. Панель и настройки НА ГРАФИКЕ.          |
//|  Спред = Ask-Bid каждого символа в терминале.                    |
//+------------------------------------------------------------------+
#property copyright "STRATUM"
#property link      ""
#property version   "3.00"
#property strict
#property description "Панель + настройки на графике. Спред из терминала."

input string  WatchList       = "EURUSD,GBPUSD,USDJPY,XAUUSD,AUDUSD,USDCAD,USDCHF,NZDUSD";
input string  BrokerSuffix    = "";
input int     WorkTF          = 240;
input bool    AutoTrade       = false;
input double  Lots            = 0.10;
input int     Magic           = 220826;
input int     SlippagePoints  = 20;
input int     MaxSpreadPoints = 30;
input double  MinCover        = 2.2;
input double  MinNetRR        = 1.0;
input int     OneTradeOnly    = 1;
input bool    AlertsOn        = true;
input int     SwingPad        = 2;
input int     Lookback        = 80;
input double  AtrStopMult     = 0.35;
input int     PanelX          = 8;
input int     PanelY          = 18;

#define P "STRATUM_"
#define MAXSYM 12

string   g_sym[];
int      g_n;
string   g_lastKey[MAXSYM];
datetime g_lastBar[MAXSYM];

string g_watch;
string g_suffix;
int    g_tf;
bool   g_auto;
double g_lots;
int    g_maxSp;
bool   g_alerts;
bool   g_seeded = false;
bool   g_ready = false;

color C_BG   = C'16,14,12';
color C_BOX  = C'32,28,24';
color C_LINE = C'72,64,52';
color C_GOLD = C'212,184,140';
color C_DIM  = C'150,140,126';
color C_FG   = C'236,228,214';
color C_BUY  = C'110,158,134';
color C_SEL  = C'181,122,122';
color C_WAIT = C'196,168,110';
color C_OFF  = C'90,84,76';

int OnInit()
  {
   g_watch  = WatchList;
   g_suffix = BrokerSuffix;
   g_tf     = WorkTF;
   g_auto   = AutoTrade;
   g_lots   = Lots;
   g_maxSp  = MaxSpreadPoints;
   g_alerts = AlertsOn;
   ParseWatch();
   EventSetTimer(1);
   ChartSetInteger(0, CHART_FOREGROUND, false);
   g_ready = true;
   g_seeded = false;
   DrawDesk();
   return(INIT_SUCCEEDED);
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   Wipe();
   Comment("");
  }

void OnTick()   { if(g_ready) DrawDesk(); }
void OnTimer()  { if(g_ready) DrawDesk(); }

void OnChartEvent(const int id, const long &lparam, const double &dparam, const string &sparam)
  {
   if(id != CHARTEVENT_OBJECT_CLICK) return;
   ObjectSetInteger(0, sparam, OBJPROP_STATE, false);
   if(sparam == P+"b_auto")
     {
      g_auto = !g_auto;
      DrawDesk();
      return;
     }
   if(sparam == P+"b_alrt")
     {
      g_alerts = !g_alerts;
      DrawDesk();
      return;
     }
   if(sparam == P+"b_ok")
     {
      ApplyEdits();
      g_seeded = false;
      DrawDesk();
     }
  }

void ApplyEdits()
  {
   string lots = ObjectGetString(0, P+"e_lots", OBJPROP_TEXT);
   string sp   = ObjectGetString(0, P+"e_spread", OBJPROP_TEXT);
   string tf   = ObjectGetString(0, P+"e_tf", OBJPROP_TEXT);
   string suf  = ObjectGetString(0, P+"e_suf", OBJPROP_TEXT);
   string wl   = ObjectGetString(0, P+"e_list", OBJPROP_TEXT);
   double l = StringToDouble(lots);
   int    s = (int)StringToInteger(sp);
   int    t = (int)StringToInteger(tf);
   if(l > 0) g_lots = l;
   if(s > 0) g_maxSp = s;
   if(t == 15 || t == 30 || t == 60 || t == 240 || t == 1440) g_tf = t;
   g_suffix = suf;
   if(StringLen(wl) > 2) g_watch = wl;
   ParseWatch();
  }

void ParseWatch()
  {
   ArrayResize(g_sym, 0);
   g_n = 0;
   string raw = g_watch;
   StringReplace(raw, " ", "");
   string parts[];
   int n = StringSplit(raw, ',', parts);
   for(int i = 0; i < n; i++)
     {
      string s = parts[i];
      if(StringLen(g_suffix) > 0 && StringFind(s, g_suffix) < 0) s = s + g_suffix;
      if(StringLen(s) == 0) continue;
      SymbolSelect(s, true);
      if(g_n >= MAXSYM) break;
      ArrayResize(g_sym, g_n + 1);
      g_sym[g_n] = s;
      g_lastKey[g_n] = "";
      g_lastBar[g_n] = 0;
      g_n++;
     }
   if(g_n == 0)
     {
      ArrayResize(g_sym, 1);
      g_sym[0] = Symbol();
      g_n = 1;
     }
  }

int    DigitsOf(string s) { return((int)MarketInfo(s, MODE_DIGITS)); }
double PointOf(string s)  { return(MarketInfo(s, MODE_POINT)); }
double BidOf(string s)    { return(MarketInfo(s, MODE_BID)); }
double AskOf(string s)    { return(MarketInfo(s, MODE_ASK)); }
double SpreadPr(string s) { return(AskOf(s) - BidOf(s)); }
int    SpreadPt(string s)
  {
   double pt = PointOf(s);
   if(pt <= 0) return(0);
   return((int)MathRound(SpreadPr(s) / pt));
  }
int BarsOf(string s) { return(iBars(s, g_tf)); }
string Px(string s, double v) { return(DoubleToStr(v, DigitsOf(s))); }

bool IsSH(string s, int i)
  {
   int bars = BarsOf(s);
   if(i < SwingPad || i + SwingPad >= bars) return(false);
   double h = iHigh(s, g_tf, i);
   for(int k = 1; k <= SwingPad; k++)
      if(h <= iHigh(s, g_tf, i - k) || h < iHigh(s, g_tf, i + k)) return(false);
   return(true);
  }
bool IsSL(string s, int i)
  {
   int bars = BarsOf(s);
   if(i < SwingPad || i + SwingPad >= bars) return(false);
   double l = iLow(s, g_tf, i);
   for(int k = 1; k <= SwingPad; k++)
      if(l >= iLow(s, g_tf, i - k) || l > iLow(s, g_tf, i + k)) return(false);
   return(true);
  }
int LastSH(string s)
  {
   int lim = MathMin(Lookback, BarsOf(s) - SwingPad - 1);
   for(int i = SwingPad; i <= lim; i++) if(IsSH(s, i)) return(i);
   return(-1);
  }
int LastSL(string s)
  {
   int lim = MathMin(Lookback, BarsOf(s) - SwingPad - 1);
   for(int i = SwingPad; i <= lim; i++) if(IsSL(s, i)) return(i);
   return(-1);
  }
int PrevSH(string s, int after)
  {
   int lim = MathMin(Lookback, BarsOf(s) - SwingPad - 1);
   for(int i = after + 1; i <= lim; i++) if(IsSH(s, i)) return(i);
   return(-1);
  }
int PrevSL(string s, int after)
  {
   int lim = MathMin(Lookback, BarsOf(s) - SwingPad - 1);
   for(int i = after + 1; i <= lim; i++) if(IsSL(s, i)) return(i);
   return(-1);
  }
int CountMine(string s)
  {
   int n = 0;
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      if(!OrderSelect(i, SELECT_BY_POS, MODE_TRADES)) continue;
      if(OrderSymbol() == s && OrderMagicNumber() == Magic) n++;
     }
   return(n);
  }

void Scan(int idx, string &bias, string &verdict, string &why,
          int &dir, double &entry, double &stop, double &target, int &spPts)
  {
   string s = g_sym[idx];
   double bid = BidOf(s);
   double ask = AskOf(s);
   spPts = SpreadPt(s);
   double spread = SpreadPr(s);
   double atr = iATR(s, g_tf, 14, 1);
   if(atr <= 0) atr = PointOf(s) * 20;
   dir = 0; entry = 0; stop = 0; target = 0;
   bias = "—"; verdict = "НЕТ ДАННЫХ"; why = "бары";
   int sh = LastSH(s); int sl = LastSL(s);
   if(sh < 0 || sl < 0) return;
   int sh2 = PrevSH(s, sh); int sl2 = PrevSL(s, sl);
   double hi = iHigh(s, g_tf, sh);
   double lo = iLow(s, g_tf, sl);
   double eq = (hi + lo) / 2.0;
   int trend = 0;
   if(sh2 >= 0 && sl2 >= 0)
     {
      if(iHigh(s, g_tf, sh) > iHigh(s, g_tf, sh2) && iLow(s, g_tf, sl) > iLow(s, g_tf, sl2)) trend = 1;
      if(iHigh(s, g_tf, sh) < iHigh(s, g_tf, sh2) && iLow(s, g_tf, sl) < iLow(s, g_tf, sl2)) trend = -1;
     }
   if(trend > 0) bias = "бычий";
   else if(trend < 0) bias = "медвеж.";
   else bias = "флэт";
   string reason = "ждём край";
   if(trend > 0 && bid < eq) { dir = 1; entry = ask; stop = lo - atr * AtrStopMult; target = hi; reason = "дисконт"; }
   else if(trend < 0 && bid > eq) { dir = -1; entry = bid; stop = hi + atr * AtrStopMult; target = lo; reason = "премия"; }
   if(spPts > g_maxSp) { dir = 0; verdict = "СПРЕД"; why = IntegerToString(spPts)+"п"; return; }
   if(dir == 0) { verdict = "ЖДАТЬ"; why = reason; return; }
   double grossR = MathAbs(target - (dir > 0 ? bid : ask));
   double grossK = MathAbs((dir > 0 ? bid : ask) - stop);
   double roundT = 2.0 * spread;
   double netR = grossR - spread;
   double netK = grossK + spread;
   double covers = (roundT > 0 ? grossR / roundT : 0);
   double rr = (netK > 0 ? netR / netK : 0);
   if(netR <= 0 || covers < MinCover || rr < MinNetRR)
     { dir = 0; verdict = "СПРЕД"; why = "круг"; return; }
   verdict = (dir > 0 ? "ЛОНГ" : "ШОРТ");
   why = "RR "+DoubleToStr(rr, 1);
  }

void MaybeTrade(int idx, int dir, double stop, double target, string verdict, int spPts)
  {
   string s = g_sym[idx];
   datetime bar = iTime(s, g_tf, 0);
   string key = s + verdict + TimeToStr(bar, TIME_DATE|TIME_MINUTES);
   if(key == g_lastKey[idx]) return;
   g_lastKey[idx] = key;
   if(dir == 0) return;
   if(g_alerts) Alert("STRATUM ", s, " ", verdict, " ", IntegerToString(spPts), "pt");
   if(!g_auto) return;
   if(OneTradeOnly > 0 && CountMine(s) >= OneTradeOnly) return;
   RefreshRates();
   int digits = DigitsOf(s);
   double px = (dir > 0 ? AskOf(s) : BidOf(s));
   int ticket = OrderSend(s, dir > 0 ? OP_BUY : OP_SELL, g_lots, px, SlippagePoints,
                          NormalizeDouble(stop, digits), NormalizeDouble(target, digits),
                          "STRATUM", Magic, 0, dir > 0 ? C_BUY : C_SEL);
   if(ticket < 0) Print("STRATUM ", s, " err ", GetLastError());
  }

void Wipe()
  {
   for(int i = ObjectsTotal() - 1; i >= 0; i--)
     {
      string n = ObjectName(i);
      if(StringFind(n, P) == 0) ObjectDelete(n);
     }
  }

void Rect(string id, int x, int y, int w, int h, color bg)
  {
   string n = P + id;
   if(ObjectFind(0, n) < 0)
     {
      if(!ObjectCreate(0, n, OBJ_RECTANGLE_LABEL, 0, 0, 0))
         ObjectCreate(n, OBJ_RECTANGLE_LABEL, 0, 0, 0);
     }
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, n, OBJPROP_COLOR, C_LINE);
   ObjectSetInteger(0, n, OBJPROP_BORDER_TYPE, BORDER_FLAT);
   ObjectSetInteger(0, n, OBJPROP_WIDTH, 1);
   ObjectSetInteger(0, n, OBJPROP_BACK, false);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
  }

void Lab(string id, int x, int y, string text, color clr, int size)
  {
   string n = P + id;
   if(ObjectFind(0, n) < 0)
     {
      if(!ObjectCreate(0, n, OBJ_LABEL, 0, 0, 0))
         ObjectCreate(n, OBJ_LABEL, 0, 0, 0);
     }
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_COLOR, clr);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, size);
   ObjectSetString(0, n, OBJPROP_FONT, "Arial");
   ObjectSetString(0, n, OBJPROP_TEXT, text);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, false);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, true);
  }

void Btn(string id, int x, int y, int w, int h, string text, color bg)
  {
   string n = P + id;
   if(ObjectFind(0, n) < 0)
     {
      if(!ObjectCreate(0, n, OBJ_BUTTON, 0, 0, 0))
         ObjectCreate(n, OBJ_BUTTON, 0, 0, 0);
     }
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, bg);
   ObjectSetInteger(0, n, OBJPROP_COLOR, C_BG);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, 8);
   ObjectSetString(0, n, OBJPROP_FONT, "Arial");
   ObjectSetString(0, n, OBJPROP_TEXT, text);
   ObjectSetInteger(0, n, OBJPROP_STATE, false);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, true);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, false);
  }

void Edit(string id, int x, int y, int w, int h, string text, bool force)
  {
   string n = P + id;
   if(ObjectFind(0, n) < 0)
     {
      if(!ObjectCreate(0, n, OBJ_EDIT, 0, 0, 0))
         ObjectCreate(n, OBJ_EDIT, 0, 0, 0);
      force = true;
     }
   ObjectSetInteger(0, n, OBJPROP_CORNER, CORNER_LEFT_UPPER);
   ObjectSetInteger(0, n, OBJPROP_XDISTANCE, x);
   ObjectSetInteger(0, n, OBJPROP_YDISTANCE, y);
   ObjectSetInteger(0, n, OBJPROP_XSIZE, w);
   ObjectSetInteger(0, n, OBJPROP_YSIZE, h);
   ObjectSetInteger(0, n, OBJPROP_BGCOLOR, C_BOX);
   ObjectSetInteger(0, n, OBJPROP_COLOR, C_FG);
   ObjectSetInteger(0, n, OBJPROP_FONTSIZE, 8);
   ObjectSetString(0, n, OBJPROP_FONT, "Arial");
   if(force) ObjectSetString(0, n, OBJPROP_TEXT, text);
   ObjectSetInteger(0, n, OBJPROP_SELECTABLE, true);
   ObjectSetInteger(0, n, OBJPROP_HIDDEN, false);
  }

color VClr(string v)
  {
   if(v == "ЛОНГ") return(C_BUY);
   if(v == "ШОРТ") return(C_SEL);
   if(v == "СПРЕД" || v == "НЕТ ДАННЫХ") return(C_OFF);
   return(C_WAIT);
  }

void DrawDesk()
  {
   int x = PanelX;
   int y = PanelY;
   int w = 720;
   int setH = 92;
   int rowH = 22;
   int head = 24;
   int h = setH + head + rowH * g_n + 20;

   Rect("bg", x, y, w, h, C_BG);
   Lab("title", x + 14, y + 8, "STRATUM DESK", C_GOLD, 12);
   Lab("hint", x + 150, y + 12, "настройки на графике   спред Ask-Bid терминала", C_DIM, 8);

   Btn("b_auto", x + 500, y + 8, 100, 22, g_auto ? "АВТО ВКЛ" : "АВТО ВЫКЛ", g_auto ? C_SEL : C_GOLD);
   Btn("b_alrt", x + 606, y + 8, 100, 22, g_alerts ? "АЛЕРТ ВКЛ" : "АЛЕРТ ВЫКЛ", C_GOLD);

   bool seed = !g_seeded;
   g_seeded = true;
   Lab("l_lots", x + 14, y + 38, "лот", C_DIM, 8);
   Edit("e_lots", x + 40, y + 36, 50, 20, DoubleToStr(g_lots, 2), seed);

   Lab("l_sp", x + 100, y + 38, "макс спред", C_DIM, 8);
   Edit("e_spread", x + 170, y + 36, 44, 20, IntegerToString(g_maxSp), seed);

   Lab("l_tf", x + 224, y + 38, "TF мин", C_DIM, 8);
   Edit("e_tf", x + 270, y + 36, 50, 20, IntegerToString(g_tf), seed);

   Lab("l_suf", x + 330, y + 38, "суффикс", C_DIM, 8);
   Edit("e_suf", x + 384, y + 36, 70, 20, g_suffix, seed);

   Btn("b_ok", x + 470, y + 36, 90, 22, "ПРИМЕНИТЬ", C_GOLD);

   Lab("l_list", x + 14, y + 64, "пары", C_DIM, 8);
   Edit("e_list", x + 50, y + 62, 654, 20, g_watch, seed);

   int hx = x + 14;
   int hy = y + setH + 2;
   Lab("h1", hx,     hy, "СИМВОЛ",  C_DIM, 8);
   Lab("h2", hx+110, hy, "СПРЕД",   C_DIM, 8);
   Lab("h3", hx+170, hy, "СТРУКТ.", C_DIM, 8);
   Lab("h4", hx+250, hy, "ВХОД",    C_DIM, 8);
   Lab("h5", hx+350, hy, "СТОП",    C_DIM, 8);
   Lab("h6", hx+450, hy, "ЦЕЛЬ",    C_DIM, 8);
   Lab("h7", hx+550, hy, "ВЕРДИКТ", C_DIM, 8);

   string cmt = "STRATUM DESK | лот "+DoubleToStr(g_lots, 2)+" | авто "+(g_auto?"ВКЛ":"ВЫКЛ")+" | макс спред "+IntegerToString(g_maxSp)+"п\n";
   cmt += "СИМВОЛ     СПРЕД  СТРУКТ   ВХОД        СТОП        ЦЕЛЬ        ВЕРДИКТ\n";

   for(int i = 0; i < g_n; i++)
     {
      string bias, verdict, why;
      int dir = 0, spPts = 0;
      double entry = 0, stop = 0, target = 0;
      Scan(i, bias, verdict, why, dir, entry, stop, target, spPts);
      MaybeTrade(i, dir, stop, target, verdict, spPts);

      int ry = y + setH + head + i * rowH;
      Rect("r"+IntegerToString(i), x + 8, ry - 2, w - 16, rowH - 2, C_BOX);
      string s = g_sym[i];
      Lab("s"+IntegerToString(i), hx,     ry, s, C_FG, 9);
      Lab("p"+IntegerToString(i), hx+110, ry, IntegerToString(spPts)+" п", C_GOLD, 9);
      Lab("b"+IntegerToString(i), hx+170, ry, bias, C_DIM, 9);
      Lab("e"+IntegerToString(i), hx+250, ry, entry > 0 ? Px(s, entry) : "—", C_FG, 9);
      Lab("k"+IntegerToString(i), hx+350, ry, stop > 0 ? Px(s, stop) : "—", C_SEL, 9);
      Lab("t"+IntegerToString(i), hx+450, ry, target > 0 ? Px(s, target) : "—", C_BUY, 9);
      Lab("v"+IntegerToString(i), hx+550, ry, verdict+"  "+why, VClr(verdict), 9);

      cmt += s;
      while(StringLen(s) < 10) { s = s + " "; }
      cmt += "  " + IntegerToString(spPts) + "п  " + bias + "  " + verdict + "  " + why + "\n";
     }
   Comment(cmt);
   ChartRedraw();
  }
